[![Github All Releases](https://img.shields.io/github/downloads/Nugetzrul3/CPU-GUI-Miner/total.svg)]()

# CPU-GUI-Miner
##### A CPU GUI miner that supports a variety CPU mining algorithms

This miner utilises Rickillerz's cpuminer: https://github.com/RickillerZ/cpuminer-RKZ

Special thanks to [itwysgsl](https://github.com/itwysgsl) and [Rick~z](https://github.com/RickillerZ) for contributing to this project

### To Run:

1. Download and extract file to directory (antivirus may remove the cpuminer and the CPUGUIMINER)
2. Run batch file
3. Fill out required information, choose required algorithm, then either click 'Start Solo' or 'Start Pool'. You may also wish to save the configuration

**Important:**   
**When exiting miner, please click 'Stop Miners and Exit', as sometimes the miner process may still run even when you close the application**

![Before](https://i.imgur.com/EoyR28O.png)

![After](https://i.imgur.com/dSb0zDP.png)

![Solo and Pool Mining](https://i.imgur.com/sJ34kgL.png)

**If you like this miner, please star and feel free to donate:**
* BTC: bc1qdyxqyunfyj7ejrvw8zsun8582vazktejp6azsu
* ETH: 0xd92e51C7BBF45FC4E975d0331b4d60c126D9AdF4
* DOGE: DCeJfVfwTeXFwv3JNyjeQWbFaYmMCcsR4X
* SUGAR: sugar1qtl7u435t4jly2hdaa7hrcv5qkpvwa0spd9zzc7
